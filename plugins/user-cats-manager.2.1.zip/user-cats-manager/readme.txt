=== Plugin Name ===
Contributors: DGmike
Donate link: http://dgmike.wordpress.com
Tags: categories, users, level, preferences, access
Requires at least: 2.5
Tested up to: 2.5
Stable tag: 2.1

Provides to admin users a way to select what categorie determined users can write. (administrators have access to all categories)

== Description ==

Provides to admin users a way to select what categorie determined users can write. (administrators have access to all categories)

== Installation ==

1. Upload `user-cats-manager.php` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Access the `Categories And Users` in your settings options.
1. Select the user. And click on `edit` button.
1. A list of categories and subcategories are showed for you.
1. Select what categories that user can use write/edit posts.
1. Click on `save` button.

Note: Administrators can write on any categorie by default, so use editors for new users.

== Frequently Asked Questions ==

= Wy my preferences are reseted when I unistall the plugin? =

All the preferences are deleted for provide a best performance of wordpress. So, if you remove this plugin, all your preferences goes away.

= My users can write in any categorie. Why? =

Administrator have access to all preferences on your blog, this inclues the administration of user-cats-manager, so hano no sense it have restrict access. If the users are setted as Administrator, it can write on any categorie. So, for new users choose editor mode.

You can read more about in http://codex.wordpress.org/Roles_and_Capabilities

You can use too the *Role Manager* to have more control of your users. http://www.im-web-gefunden.de/wordpress-plugins/role-manager/

== Screenshots ==

1. Main settings page.
